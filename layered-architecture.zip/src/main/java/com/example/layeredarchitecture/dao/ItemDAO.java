package com.example.layeredarchitecture.dao;

public interface ItemDAO {
}
